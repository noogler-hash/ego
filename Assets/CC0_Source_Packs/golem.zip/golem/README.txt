Golem - free sprite sheets (CC0)

A mossy stone golem with an amber core: idle, walk, attack, hurt and death, facing left.

Sheets (8 frames per row, read left to right, top to bottom):
- golem-idle.png: 21 frames, 288x301 cells, 5 fps, loop, pivot 149,271
- golem-walk.png: 20 frames, 288x301 cells, 10 fps, loop, pivot 149,271
- golem-attack.png: 28 frames, 288x301 cells, 15 fps, plays once, pivot 149,271
- golem-hurt.png: 8 frames, 288x301 cells, 15 fps, plays once, pivot 149,271
- golem-death.png: 24 frames, 288x301 cells, 15 fps, plays once, pivot 149,271

Each JSON file is a JSON Hash atlas: load it with Phaser's load.atlas or PixiJS Assets.
Frame durations are in milliseconds; pivot is the foot point, normalized to the cell.

Made with SpriteCanvas: https://spritecanvas.com/free-sprite-sheets/
